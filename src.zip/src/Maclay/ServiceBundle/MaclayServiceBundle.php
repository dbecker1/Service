<?php

namespace Maclay\ServiceBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MaclayServiceBundle extends Bundle
{
}
